There are 3 directories created from the zip file:

Documentation: Contains documentation.html file on how to setup the OneBox
		module code. Also contains an example XML file (XML_Example.xml) which
		is the output of a properly working web service. 

GSA Code: The XML file that gets imported into the Google Search Appliance
		and formats the XML ouput from the Web Service as a OneBox module via XSLT.

Web Service: This code runs on an IIS server and returns the XML data used
		by the OneBox module on the GSA.